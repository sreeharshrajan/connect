-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2021 at 09:12 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `connectfinal`
--

-- --------------------------------------------------------

--
-- Table structure for table `activitybin`
--

CREATE TABLE `activitybin` (
  `entryNo` int(11) NOT NULL,
  `binID` varchar(5) NOT NULL,
  `styleID` varchar(10) NOT NULL,
  `brandStyle` date NOT NULL,
  `brandMasters` date NOT NULL,
  `merchStory` date NOT NULL,
  `PCMupload` date NOT NULL,
  `samplesBinned` date NOT NULL,
  `shootsDone` date NOT NULL,
  `editing` date NOT NULL,
  `visualQC` date NOT NULL,
  `content` date NOT NULL,
  `finalQC` date NOT NULL,
  `liveStyle` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activitybin`
--

INSERT INTO `activitybin` (`entryNo`, `binID`, `styleID`, `brandStyle`, `brandMasters`, `merchStory`, `PCMupload`, `samplesBinned`, `shootsDone`, `editing`, `visualQC`, `content`, `finalQC`, `liveStyle`) VALUES
(36, 'B1', '80', '2021-06-11', '0000-00-00', '2021-06-18', '0000-00-00', '2021-06-16', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00'),
(37, 'B2', '81', '2021-06-10', '2021-06-03', '2021-06-17', '2021-06-10', '2021-06-17', '2021-06-22', '2021-06-09', '2021-06-09', '2021-06-23', '2021-06-17', '2021-06-10');

-- --------------------------------------------------------

--
-- Table structure for table `styles`
--

CREATE TABLE `styles` (
  `serialNo` int(4) NOT NULL,
  `styleid` varchar(25) NOT NULL,
  `season` varchar(5) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `gender` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `product` varchar(50) NOT NULL,
  `pcmid` varchar(20) NOT NULL,
  `ean` varchar(20) NOT NULL,
  `image` varchar(500) NOT NULL DEFAULT 'default.png',
  `mode` text NOT NULL,
  `status` text NOT NULL,
  `fit` varchar(30) NOT NULL,
  `pattern` varchar(30) NOT NULL,
  `closure` varchar(30) NOT NULL,
  `length` varchar(30) NOT NULL,
  `color` varchar(30) NOT NULL,
  `occassion` varchar(30) NOT NULL,
  `style` varchar(30) NOT NULL,
  `material` varchar(30) NOT NULL,
  `sleeve` varchar(30) NOT NULL,
  `pockets` varchar(30) NOT NULL,
  `neckline` varchar(30) NOT NULL,
  `collar` varchar(25) NOT NULL,
  `others` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `tna`
--

CREATE TABLE `tna` (
  `sNo` int(11) NOT NULL,
  `binID` varchar(5) DEFAULT NULL,
  `styleID` varchar(10) NOT NULL,
  `activity` varchar(100) NOT NULL DEFAULT 'No Activity Added Yet',
  `pDate` date NOT NULL DEFAULT current_timestamp(),
  `aDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `logid` int(10) NOT NULL,
  `uId` int(10) NOT NULL,
  `userEmail` varchar(255) CHARACTER SET latin1 NOT NULL,
  `userIp` varbinary(16) NOT NULL,
  `city` varchar(255) CHARACTER SET latin1 NOT NULL,
  `country` varchar(255) CHARACTER SET latin1 NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`logid`, `uId`, `userEmail`, `userIp`, `city`, `country`, `loginTime`) VALUES
(44, 25, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-04 14:21:30'),
(45, 25, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-04 14:22:56'),
(46, 25, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-04 14:23:52'),
(47, 25, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-04 14:37:31'),
(48, 25, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-04 19:02:39'),
(49, 25, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-04 19:11:58');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(25, 'Sreeharsh K', 'sreeharshkrajan@gmail.com', '123456');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activitybin`
--
ALTER TABLE `activitybin`
  ADD PRIMARY KEY (`entryNo`),
  ADD UNIQUE KEY `styleID` (`styleID`);

--
-- Indexes for table `styles`
--
ALTER TABLE `styles`
  ADD PRIMARY KEY (`styleid`),
  ADD UNIQUE KEY `ean` (`ean`),
  ADD UNIQUE KEY `pcmid` (`pcmid`),
  ADD UNIQUE KEY `serialNo` (`serialNo`);

--
-- Indexes for table `tna`
--
ALTER TABLE `tna`
  ADD PRIMARY KEY (`sNo`),
  ADD UNIQUE KEY `sNo` (`sNo`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activitybin`
--
ALTER TABLE `activitybin`
  MODIFY `entryNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;

--
-- AUTO_INCREMENT for table `styles`
--
ALTER TABLE `styles`
  MODIFY `serialNo` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=82;

--
-- AUTO_INCREMENT for table `tna`
--
ALTER TABLE `tna`
  MODIFY `sNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=135;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `logid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=50;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
