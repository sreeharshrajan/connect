-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 04, 2021 at 12:14 PM
-- Server version: 10.4.19-MariaDB
-- PHP Version: 8.0.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `connect`
--

-- --------------------------------------------------------

--
-- Table structure for table `activitybin`
--

CREATE TABLE `activitybin` (
  `entryNo` int(11) NOT NULL,
  `binID` varchar(5) NOT NULL,
  `styleID` varchar(10) NOT NULL,
  `brandStyle` date NOT NULL,
  `brandMasters` date NOT NULL,
  `merchStory` date NOT NULL,
  `PCMupload` date NOT NULL,
  `samplesBinned` date NOT NULL,
  `shootsDone` date NOT NULL,
  `editing` date NOT NULL,
  `visualQC` date NOT NULL,
  `content` date NOT NULL,
  `finalQC` date NOT NULL,
  `liveStyle` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `activitybin`
--

INSERT INTO `activitybin` (`entryNo`, `binID`, `styleID`, `brandStyle`, `brandMasters`, `merchStory`, `PCMupload`, `samplesBinned`, `shootsDone`, `editing`, `visualQC`, `content`, `finalQC`, `liveStyle`) VALUES
(20, 'B2', '73', '2021-06-23', '2021-06-06', '2021-06-10', '2021-06-09', '2021-06-09', '2021-06-12', '2021-06-11', '2021-06-17', '2021-06-18', '2021-06-27', '2021-06-25'),
(29, 'B2', '68', '2021-06-25', '2021-06-19', '2021-06-10', '0000-00-00', '2021-06-16', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00'),
(30, 'B2', '71', '2021-06-05', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00', '0000-00-00'),
(32, 'B1', '70', '2021-06-10', '2021-06-11', '2021-06-11', '2021-06-18', '2021-06-15', '2021-06-16', '2021-06-17', '2021-06-17', '2021-06-24', '2021-06-19', '2021-06-12'),
(34, 'B1', '72', '2021-06-10', '2021-06-11', '2021-06-11', '2021-06-18', '2021-06-15', '2021-06-16', '2021-06-17', '2021-06-17', '2021-06-24', '2021-06-19', '2021-06-12');

-- --------------------------------------------------------

--
-- Table structure for table `styles`
--

CREATE TABLE `styles` (
  `serialNo` int(4) NOT NULL,
  `styleid` varchar(25) NOT NULL,
  `season` varchar(5) NOT NULL,
  `brand` varchar(50) NOT NULL,
  `gender` text NOT NULL,
  `category` varchar(50) NOT NULL,
  `product` varchar(50) NOT NULL,
  `pcmid` varchar(20) NOT NULL,
  `ean` varchar(20) NOT NULL,
  `image` varchar(500) NOT NULL DEFAULT 'default.png',
  `mode` text NOT NULL,
  `status` text NOT NULL,
  `fit` varchar(30) NOT NULL,
  `pattern` varchar(30) NOT NULL,
  `closure` varchar(30) NOT NULL,
  `length` varchar(30) NOT NULL,
  `color` varchar(30) NOT NULL,
  `occassion` varchar(30) NOT NULL,
  `style` varchar(30) NOT NULL,
  `material` varchar(30) NOT NULL,
  `sleeve` varchar(30) NOT NULL,
  `pockets` varchar(30) NOT NULL,
  `neckline` varchar(30) NOT NULL,
  `others` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `styles`
--

INSERT INTO `styles` (`serialNo`, `styleid`, `season`, `brand`, `gender`, `category`, `product`, `pcmid`, `ean`, `image`, `mode`, `status`, `fit`, `pattern`, `closure`, `length`, `color`, `occassion`, `style`, `material`, `sleeve`, `pockets`, `neckline`, `others`) VALUES
(71, '77WW', 'AW21', 'Flying Machine', 'Women', 'Ethnic wear', 'Kurtas', '89W9', '99W', 'man.jpg', 'given', 'WIP', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'ACB'),
(72, '77WWA', 'SS21', 'The Childrens Place', 'Men', 'Bottomwear', 'Track Pants', '556AA', 'EA426', 'defualt.png', 'yetto', 'Catalouged', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL'),
(77, 'EO77', 'AW21', 'Aeropostale', 'Women', 'Bottomwear', 'Track Pants', '78W', '78W', '', 'given', ' wip', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL'),
(70, 'EPQ77', 'AW21', 'Flying Machine', 'Men', 'Innerwear', 'Trunks', 'EE889', '78WW', 'wdress.png', 'given', ' wip', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL'),
(68, 'EW45E', 'AW21', 'Calvin Klein', 'Men', 'Topwear', 'Formal Shirts', '52AE', '85EE', 'man.jpg', 'yetto', ' wip', 'EEE', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL'),
(73, 'W12E5', 'SS21', 'USPA', 'Women', 'Bottomwear', 'Jeggings', '66PP', '445E', 'wdress.png', 'given', ' wip', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL', 'NIL'),
(78, 'ZEEE7', 'AW21', 'Flying Machine', 'Women', 'Ethnic wear', 'Kurtas', 'EE7', '7EA', '', 'given', ' wip', 'N', '4', '6', 'AA', '5', 'sa', 'kdsk', 'knk', 'kknnk', 'nkk', 'nkn', 'knk');

-- --------------------------------------------------------

--
-- Table structure for table `tna`
--

CREATE TABLE `tna` (
  `sNo` int(11) NOT NULL,
  `binID` varchar(5) DEFAULT NULL,
  `styleID` varchar(10) NOT NULL,
  `activity` varchar(100) NOT NULL DEFAULT 'No Activity Added Yet',
  `pDate` date NOT NULL DEFAULT current_timestamp(),
  `aDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tna`
--

INSERT INTO `tna` (`sNo`, `binID`, `styleID`, `activity`, `pDate`, `aDate`) VALUES
(60, 'B2', '71', 'Editing', '0000-00-00', '0000-00-00'),
(61, 'B2', '71', 'Visual QC(VQC)', '0000-00-00', '0000-00-00'),
(62, 'B2', '71', 'Content', '0000-00-00', '0000-00-00'),
(63, 'B2', '71', 'Final QC(FQC)', '0000-00-00', '0000-00-00'),
(64, 'B2', '71', 'Style Go Live', '0000-00-00', '0000-00-00'),
(65, 'B1', '68', 'Brand Style Selection', '2021-06-10', '0000-00-00'),
(66, 'B1', '68', 'Brand Online Masters', '2021-06-11', '0000-00-00'),
(67, 'B1', '68', 'Merch Story Curation', '2021-06-11', '0000-00-00'),
(68, 'B1', '68', 'Samples are Binned', '2021-06-15', '0000-00-00'),
(69, 'B1', '68', 'Shoot done as per target', '2021-06-16', '0000-00-00'),
(70, 'B1', '68', 'Editing', '2021-06-17', '0000-00-00'),
(71, 'B1', '68', 'Visual QC(VQC)', '2021-06-17', '0000-00-00'),
(72, 'B1', '68', 'Content', '2021-06-24', '0000-00-00'),
(73, 'B1', '68', 'Final QC(FQC)', '2021-06-19', '0000-00-00'),
(74, 'B1', '68', 'Style Go Live', '2021-06-12', '0000-00-00'),
(75, 'B1', '70', 'Brand Style Selection', '2021-06-10', '0000-00-00'),
(76, 'B1', '70', 'Brand Online Masters', '2021-06-11', '0000-00-00'),
(77, 'B1', '70', 'Merch Story Curation', '2021-06-11', '0000-00-00'),
(78, 'B1', '70', 'Samples are Binned', '2021-06-15', '0000-00-00'),
(79, 'B1', '70', 'Shoot done as per target', '2021-06-16', '0000-00-00'),
(80, 'B1', '70', 'Editing', '2021-06-17', '0000-00-00'),
(81, 'B1', '70', 'Visual QC(VQC)', '2021-06-17', '0000-00-00'),
(82, 'B1', '70', 'Content', '2021-06-24', '0000-00-00'),
(83, 'B1', '70', 'Final QC(FQC)', '2021-06-19', '0000-00-00'),
(84, 'B1', '70', 'Style Go Live', '2021-06-12', '0000-00-00'),
(85, 'B1', '71', 'Brand Style Selection', '2021-06-10', '0000-00-00'),
(86, 'B1', '71', 'Brand Online Masters', '2021-06-11', '0000-00-00'),
(87, 'B1', '71', 'Merch Story Curation', '2021-06-11', '0000-00-00'),
(88, 'B1', '71', 'Samples are Binned', '2021-06-15', '0000-00-00'),
(89, 'B1', '71', 'Shoot done as per target', '2021-06-16', '0000-00-00'),
(90, 'B1', '71', 'Editing', '2021-06-17', '0000-00-00'),
(91, 'B1', '71', 'Visual QC(VQC)', '2021-06-17', '0000-00-00'),
(92, 'B1', '71', 'Content', '2021-06-24', '0000-00-00'),
(93, 'B1', '71', 'Final QC(FQC)', '2021-06-19', '0000-00-00'),
(94, 'B1', '71', 'Style Go Live', '2021-06-12', '0000-00-00'),
(95, 'B1', '72', 'Brand Style Selection', '2021-06-10', '0000-00-00'),
(96, 'B1', '72', 'Brand Online Masters', '2021-06-11', '0000-00-00'),
(97, 'B1', '72', 'Merch Story Curation', '2021-06-11', '0000-00-00'),
(98, 'B1', '72', 'Samples are Binned', '2021-06-15', '0000-00-00'),
(99, 'B1', '72', 'Shoot done as per target', '2021-06-16', '0000-00-00'),
(100, 'B1', '72', 'Editing', '2021-06-17', '0000-00-00'),
(101, 'B1', '72', 'Visual QC(VQC)', '2021-06-17', '0000-00-00'),
(102, 'B1', '72', 'Content', '2021-06-24', '0000-00-00'),
(103, 'B1', '72', 'Final QC(FQC)', '2021-06-19', '0000-00-00'),
(104, 'B1', '72', 'Style Go Live', '2021-06-12', '0000-00-00'),
(105, 'B1', '73', 'Brand Style Selection', '2021-06-10', '0000-00-00'),
(106, 'B1', '73', 'Brand Online Masters', '2021-06-11', '0000-00-00'),
(107, 'B1', '73', 'Merch Story Curation', '2021-06-11', '0000-00-00'),
(108, 'B1', '73', 'Samples are Binned', '2021-06-15', '0000-00-00'),
(109, 'B1', '73', 'Shoot done as per target', '2021-06-16', '0000-00-00'),
(110, 'B1', '73', 'Editing', '2021-06-17', '0000-00-00'),
(111, 'B1', '73', 'Visual QC(VQC)', '2021-06-17', '0000-00-00'),
(112, 'B1', '73', 'Content', '2021-06-24', '0000-00-00'),
(113, 'B1', '73', 'Final QC(FQC)', '2021-06-19', '0000-00-00'),
(114, 'B1', '73', 'Style Go Live', '2021-06-12', '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `userlog`
--

CREATE TABLE `userlog` (
  `logid` int(10) NOT NULL,
  `uId` int(10) NOT NULL,
  `userEmail` varchar(255) CHARACTER SET latin1 NOT NULL,
  `userIp` varbinary(16) NOT NULL,
  `city` varchar(255) CHARACTER SET latin1 NOT NULL,
  `country` varchar(255) CHARACTER SET latin1 NOT NULL,
  `loginTime` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `userlog`
--

INSERT INTO `userlog` (`logid`, `uId`, `userEmail`, `userIp`, `city`, `country`, `loginTime`) VALUES
(20, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-29 08:38:59'),
(21, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-29 09:42:43'),
(22, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-29 19:54:52'),
(23, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-29 20:59:33'),
(24, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-30 05:17:40'),
(25, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-30 07:41:25'),
(26, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-30 07:56:31'),
(27, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-31 16:29:50'),
(28, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-05-31 18:09:58'),
(29, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 09:53:20'),
(30, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 15:39:47'),
(31, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 15:40:10'),
(32, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 19:58:30'),
(33, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 20:14:30'),
(34, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 20:18:21'),
(35, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 20:20:08'),
(36, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 20:20:20'),
(37, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-01 20:20:27'),
(38, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-02 04:55:52'),
(39, 0, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-02 05:23:48'),
(40, 24, 'rojaj@nift', 0x3a3a31, '', '', '2021-06-02 06:51:09'),
(41, 18, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-02 07:29:24'),
(42, 18, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-02 13:13:41'),
(43, 18, 'sreeharshkrajan@gmail.com', 0x3a3a31, '', '', '2021-06-02 16:46:59');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(12) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`) VALUES
(24, 'Roja', 'rojaj@nift', 'admin'),
(18, 'Sreeharsh K', 'sreeharshkrajan@gmail.com', 'admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activitybin`
--
ALTER TABLE `activitybin`
  ADD PRIMARY KEY (`entryNo`),
  ADD UNIQUE KEY `styleID` (`styleID`);

--
-- Indexes for table `styles`
--
ALTER TABLE `styles`
  ADD PRIMARY KEY (`styleid`),
  ADD UNIQUE KEY `ean` (`ean`),
  ADD UNIQUE KEY `pcmid` (`pcmid`),
  ADD UNIQUE KEY `serialNo` (`serialNo`);

--
-- Indexes for table `tna`
--
ALTER TABLE `tna`
  ADD PRIMARY KEY (`sNo`),
  ADD UNIQUE KEY `sNo` (`sNo`);

--
-- Indexes for table `userlog`
--
ALTER TABLE `userlog`
  ADD PRIMARY KEY (`logid`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`email`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activitybin`
--
ALTER TABLE `activitybin`
  MODIFY `entryNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `styles`
--
ALTER TABLE `styles`
  MODIFY `serialNo` int(4) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=80;

--
-- AUTO_INCREMENT for table `tna`
--
ALTER TABLE `tna`
  MODIFY `sNo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `userlog`
--
ALTER TABLE `userlog`
  MODIFY `logid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
